INSERT INTO uporabnik (ime, priimek) VALUES ('Petra', 'Kos');
INSERT INTO uporabnik (ime, priimek) VALUES ('Temp', 'human');
INSERT INTO artikel(ime, st_nakupov) VALUES('cokolino',5);
INSERT INTO artikel(ime, st_nakupov) VALUES('mleko',2);
