package Uprava;

public class NakupovalniSeznamDto {

    public Integer id_seznama;
    public String naziv;

    public Integer getId_seznama() {
        return id_seznama;
    }

    public void setId_seznama(Integer id_seznama) {
        this.id_seznama = id_seznama;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
}
